% Dancing Monkeys Project
%   Karl O'Keeffe

function DancingMonkeys( MusicFullFilename, EasyDifficulty, MedDifficulty, HardDifficulty, RootDirectory, LameFullFilename, TempFile )
% Difficulty levels must be given as strings and not integers

% Remove warnings for things such as existing directories or clipped
% waveforms
warning off
tic;

% Split music filename into parts
[ Directory , FileName , FileExt , Temp ] = Fileparts( MusicFullFilename );

% Randomly generate difficulty levels if they are not given
if ( nargin < 2 )
    EasyDifficulty = int2str( ceil( rand(1)*3 ) );
end
if ( nargin < 3 )
    MedDifficulty  = int2str( 3 + ceil( rand(1)*3 ) );
end
if ( nargin < 4 )
    HardDifficulty = int2str( 6 + ceil( rand(1)*3 ) );
end

ChosenDifficultyRatings = [ str2num( EasyDifficulty ), str2num(MedDifficulty), str2num(HardDifficulty) ];

if ( nargin < 5 )
    RootDirectory = 'C:\DDR Stuff\StepMania\Songs\Example Songs\';
end

if ( nargin < 6 )
    LameFullFilename = 'C:\Program Files\Dancing Monkeys\Lame\Lame.exe';    
end
[ LamePath , LameFilename , LameFileExt , Temp ] = Fileparts( LameFullFilename );
LameExe = [ LameFilename LameFileExt ];

if ( nargin < 7 )
    TempFile = 'C:\Program Files\Dancing Monkeys\Temp Music\Temp Song.wav';        
end

% Constants
SmoothingFilterOrder = 3;               % Order for the smoothing filter.
SmoothingFilrerLowpassFrequency = 10;   % Frequency above which to discard data.
WindowLength = 5;                       % Length of the window used for normalising, in seconds.
PeakThreshold = 90;                     % Threshold for throwing away data before peak picking, in percent.
HeightWindowSize = 0.01;                % When estimating the height of a peak or through on the original waveform, this gives the size of window to use, in seconds.
BeatPositioningThreshold = 0.7;         % Between 0 and 1. How close to the calculated peak value the data must be to be considered the onset point.
MinimumBPM = 89;                        % The minimum BPM value that will be tested.
MaximumBPM = 205;                       % The maximum BPM value that will be tested.
IntervalGradientLimit = 20;             % The maximum difference between values for gaps to be considered the same.
MaxArrowsPerBar = 8;                    % The number of arrows per bar.
BarSize = 4;                            % The number of beats per bar.
BarsBeginningPadding = 2;               % The number of bars we should pad the beginning of the arrow track with.
BarsEndPadding = 1;                     % The number of bars we should pad the end of the arrow track with.
StepFilename = 'steps';                 % Name to output the step file.         
StepFileFudgeFactor = 0;                % Amount to alter the gap value by, in seconds.
FadeSeconds = 5;                        % How far from the end to start fading out the music
MaxSongLengthInSeconds = 105;           % Maximum length of music in seconds


% Check music file exists
if ( ~exist( MusicFullFilename, 'file' ) )
    error( 'Unable to find music file.' );    
end

% Check LAME decoder exists
if ( ~exist( LameFullFilename, 'file' ) )
    error( 'Unable to find LAME mp3 decoder.' );    
end


OutputFile = [ FileName '.wav' ];
OutputDirectory = [ RootDirectory FileName '\' ];

% Create Output Directory
kmkdir( RootDirectory, FileName );

% Create filename
OutputFullFilename = strcat( OutputDirectory, OutputFile );
disp( 'Initialised.' );


% Decode Mp3
if ( strcmpi( FileExt, '.wav') ) 
    TempFile = MusicFullFilename;
elseif ( strcmpi( FileExt, '.mp3') )
    LastDirectory = cd;
    cd( LamePath );
    [ Status  Result ] = dos( [ 'Lame --decode "' MusicFullFilename '" "' TempFile '"' ] );
    
    if ( Status < 0 )
        error( 'Error decoding music.' );    
    end
    
    cd( LastDirectory );
else
    error( 'unknown extension' );    
end
disp( 'Decoded Mp3 / Copied Wav' );

% Get Frequency of Wav File
[ Temp1, Frequency, Temp2 ] = wavread( TempFile, 1 );

% Get Size of Wav File
Temp = wavread( TempFile, 'size' );
NumSamples = Temp( 1 );

% Load wav file
SongSizeLimit = Frequency * MaxSongLengthInSeconds;
[ SongData, Frequency, NumBits ] = wavread( TempFile, min( [SongSizeLimit NumSamples] ) );
SongLength = size( SongData, 1 );
disp( 'Loaded song.' )

% If we had to truncate the song fade it out at the end
if ( SongLength == SongSizeLimit )
    Mask(:,1) = [1:-(1/((44100 * FadeSeconds) - 1)):0]';
    Mask(:, size(SongData, 2 ) ) = Mask(:,1);             % Need to fix for possible greater than 2 tracks.
    SongData( end - ((44100 * FadeSeconds) - 1):end, : ) = SongData( end - ((44100 * FadeSeconds) - 1):end, : ) .* Mask;
end

% Normalise Song
SongData = SongData ./ prctile( abs( SongData(:) ), 99.999 );
SongData( SongData > 1 ) = 1;
SongData( SongData < -1 ) = -1;
disp( 'Normalised song.' );

% Output the new shorter song to the StepMania or DWI songs directory
wavwrite( SongData, Frequency, NumBits, OutputFullFilename );
disp( 'Outputted truncated normalised song.' );

% Convert song to mono
NumTracks = size( SongData, 2 );
Mono = sum( SongData' ./ NumTracks, 1 )';
SongLength = size( SongData, 1 );
disp( 'Monoed song.' )


% Lowpass filter the song. This removes any high frequency data, and makes 
% it possible to peak pick the data.

% Create the Butterworth lowpass filter.
[m,n] = butter( SmoothingFilterOrder, SmoothingFilrerLowpassFrequency * 2 / Frequency );

% Filter the data both forwards and backwards in order to remove the phase
% shifts generated by filtering.
SmoothedData = filter( m, n, abs( Mono ) );
disp( 'Smoothed song.' );


% Normalise the mono and smoothed song data. This is done by taking hamming windows along
% the mono and smoothed data and normalising each window to a peak of amplitude
% 1. The windows are then added back together to make a normalied version 
% of the smoothed data. This allows for more robust peak picking.

% Length of window in seconds. Windows overlap by half the length of a
% window.
WindowSizeInSamples = round( WindowLength * Frequency );
WindowShape = hamming( WindowSizeInSamples );

% Create blank versions of the normalised data.
NormalisedMonoData   = zeros( size( Mono ) );
NormalisedSmoothData = zeros( size( Mono ) );

% Loop through each window, moving the start point of by the length of half
% a window each time.
Position = 1;
while ( Position + WindowSizeInSamples < SongLength )
    % We take the absolute value of the window in order to half wave
    % rectify the mono data. The smoothed data is already rectified.
    Window = abs( Mono( Position:(Position+WindowSizeInSamples)-1 ) );
    Window = Window ./ max( Window );
    NormalisedMonoData( Position:(Position+WindowSizeInSamples)-1 )   = NormalisedMonoData( Position:(Position+WindowSizeInSamples)-1 )   + (Window .* WindowShape);
    
    Window = SmoothedData( Position:(Position+WindowSizeInSamples)-1 );
    Window = Window ./ max( Window );
    NormalisedSmoothData( Position:(Position+WindowSizeInSamples)-1 ) = NormalisedSmoothData( Position:(Position+WindowSizeInSamples)-1 ) + (Window .* WindowShape);
    
    Position = Position + ( WindowSizeInSamples / 2 );
end

% At the end of the song we can't fit the full length of a window so just
% multiply by the part of the window shape that will fit.
Window = Mono( Position:SongLength );
Window = Window ./ max( Window );
NormalisedMonoData( Position:SongLength )   = NormalisedMonoData( Position:SongLength )   + ( Window .* WindowShape( 1:(SongLength - Position) + 1 ) );

Window = SmoothedData( Position:SongLength );
Window = Window ./ max( Window );
NormalisedSmoothData( Position:SongLength ) = NormalisedSmoothData( Position:SongLength ) + ( Window .* WindowShape( 1:(SongLength - Position) + 1 ) );


NormalisedMonoData   = NormalisedMonoData   ./ max( NormalisedMonoData   );
NormalisedSmoothData = NormalisedSmoothData ./ max( NormalisedSmoothData );
disp( 'Normalised mono and smoothed data.' );

% Now we throw away any samples not in the top 10% of the normalised
% smoothed data.

% Sort the smooted data, and take the value at the 90% percent mark as the
% limit for discarding the data.
SortedData = sort( NormalisedSmoothData );
Limit = SortedData( round( (SongLength/100) * PeakThreshold ) );


% Set any element below the limit value to 0.
PeakData = NormalisedSmoothData;
PeakData( find( PeakData < Limit ) ) = 0;
disp( 'Thresholded data' );


% Find peaks in thresholded smoothed track.
NonZeroData = PeakData( PeakData ~= 0 );
% The expression on the right finds all peaks in the NonZeroData.
IndexToNonZeroData = find(sign(-sign(diff(sign(diff( NonZeroData )))+0.5)+1))+1;
IndexToPeakData = find( PeakData ~=0 );
Peaks = IndexToPeakData( IndexToNonZeroData );


% Find all the troughs in the unthresholded smoothed data.
Troughs = find(sign(-sign(diff(sign(diff( NormalisedSmoothData )))-0.5)-1))+1;
disp( 'Found peaks and troughs.' );

% Compute the normalised strengths of each beat from 0 to 1
BeatStrengths = NormalisedSmoothData( Peaks );
BeatStrengths = BeatStrengths - min( BeatStrengths );
BeatStrengths = BeatStrengths ./ max( BeatStrengths );


% Now we try and find how much the peaks have been shifted by.

% Create a blank holder for the positions of the beats
BeatPositions = ones( size( Peaks ) );

% Loop through each peak we have found. Find the trough to the left of it.
% Now try and find the sharp onset of the beat by looking at the normalised
% rectified mono data.
for ct1 = 1 : size( Peaks, 1 )
    Peak = Peaks( ct1 ); 
    
    TroughsLessThanPeak = Troughs( Troughs < Peak );
    
    if ( size( TroughsLessThanPeak, 1 ) > 0 ) 
        NearestTrough = TroughsLessThanPeak( end );
        
        % TODO: Improve the method of estimating peak/trough height, use
        % some emperical evidence to find what works best. Also make sure
        % that it won't break at the ends of the data. Need a better way to
        % quantify which element of PeakSize we pick and why.
        
        HeightWindow = round(Frequency * HeightWindowSize);
        HalfHeightWindow = round( HeightWindow / 2 );
        
        % Find the rough height around the peak on the normalised mono data.
        Temp = sort( abs( NormalisedMonoData( Peak - HalfHeightWindow : Peak + HalfHeightWindow ) ) );
        PeakSize   = Temp( end - round( HeightWindow / 100 ) );
        
        % Find the rough height around the trough on the normalised mono data.
        Temp = sort( abs( NormalisedMonoData( NearestTrough - HalfHeightWindow :NearestTrough + HalfHeightWindow ) ) );
        TroughSize = Temp( end - round( HeightWindow / 100 ) );
        
        % Calculate the threshold at which a value is considered to be the
        % onset point.
        Threshold = ( ( PeakSize - TroughSize ) * BeatPositioningThreshold ) + TroughSize;
        
        Candidates = NormalisedMonoData( NearestTrough : Peak );
        CandidatesPos = find( Candidates >= Threshold );
        
        if ( size( CandidatesPos, 1 ) < 1 )
            Pos = 1;    % If no candidates are good enough, then take the trough as the beat position.
        else
            Pos = CandidatesPos( 1 );
        end
        BeatPos = NearestTrough + Pos - 1;
        
        BeatPositions( ct1 ) = BeatPos;
    end
end
disp( 'Found beat positions.' );


% Find the average difference between the peaks and what we think are the
% onsets. Shifting all the peak data by the same amount, rather than using
% the calculated beat positions for each one gives us much better accuracy
% in computing the BPM.

Offsets = Peaks - BeatPositions;
Offset = median( Offsets );

% Beats = Peaks - round( Offset );
Beats = BeatPositions;
disp( 'Calculated peak to beat offset.' );


% Now we brute force all possible BPMS from a very high value to a very low
% value. This involves testing each possible interval between beats and
% rating them by the amount of data that supports them being the correct
% BPM.

% The minimum BPM becomes the maximum interval, because the less beats per
% minute the longer the gap between them.
MaximumInterval = round( Frequency / ( MinimumBPM / 60 ) );
MinimumInterval = round( Frequency / ( MaximumBPM / 60 ) );

IntervalFitness  = zeros( [ (MaximumInterval - MinimumInterval + 1) 1 ] );
IntervalGap      = zeros( [ (MaximumInterval - MinimumInterval + 1) 1 ] );

% Loop through every 10th possible BPM, later we will fill in those that
% look interesting
HalfGapWindowSize = 1000;
GapWindow = hamming( HalfGapWindowSize*2 );
NumBeats = size( Beats,1 ) * 2;
for i = MinimumInterval : 10 : MaximumInterval
    %     disp( sprintf( 'Started %d', i ) );
    
    Gaps = mod( Beats, i );
    ExtraGaps = Gaps + i;
    
    FullGaps = [ Gaps ExtraGaps ]';
    FullGaps = FullGaps(:);
    [ SortedGaps SortedIndex ] = sort( FullGaps );
    
    
    % Here we take a hamming window over a small window of Gap positions
    % and record the amount of support we get from gap values within that
    % hamming window, based on the strength of the beat predictiting each
    % gap and the distance of the gap from the centre of the hamming
    % window.
    GapsFiltered = zeros( NumBeats, 1 );
    for ct1 = 1 : NumBeats
        Area = 0;
        
        Centre = SortedGaps( ct1 );
        
        Pos = ct1;
        PosVal = SortedGaps( Pos );
        while ( PosVal > Centre - HalfGapWindowSize )
            
            if Pos <= 1 
                break;
            end
            xPos = SortedIndex( Pos );
            if ( xPos > size( Beats,1 ) ) 
                xPos = xPos - size( Beats,1 );
            end
            Area = Area + ( BeatStrengths( xPos ) * GapWindow( PosVal - (Centre - HalfGapWindowSize) ) );
            Pos = Pos - 1;
            PosVal = SortedGaps( Pos );
        end
        
        Pos = ct1;
        PosVal = SortedGaps( Pos );
        while ( PosVal <= Centre + HalfGapWindowSize )
            
            if Pos >= NumBeats
                break;
            end
            xPos = SortedIndex( Pos );
            if ( xPos > size( Beats,1 ) ) 
                xPos = xPos - size( Beats,1 );
            end
            Area = Area + ( BeatStrengths( xPos ) * GapWindow( PosVal - (Centre - HalfGapWindowSize) ) );
            Pos = Pos + 1;
            PosVal = SortedGaps( Pos );
        end
        
        GapsFiltered( ct1 ) = Area;
        
    end
    
    
    % Here we work out how much evidence there is to support each gap
    % by the GapFiltered value for each gap and a portion of the
    % GapFiltered value from offbeats.
    
    % Need to take care of end cases better
    GapsConfidence = zeros( NumBeats, 1 );
    for ct1 = 1 : NumBeats -1 
        
        OffbeatPos = SortedGaps( ct1 ) + round(i / 2);
        
        % We know the position of where an offbeat gap value would be but
        % we need to work out its index in the SortedGaps array
        Pos = ct1;
        PosVal = SortedGaps( Pos );
        while ( PosVal < OffbeatPos )
            if Pos >= NumBeats - 1
                break;
            end
            Pos = Pos + 1;
            PosVal = SortedGaps( Pos );
        end

        % Not sure why I have this taking the average of the two nearest
        % gaps. Might give some improvement to accuracy, but most probably
        % pointless.
        OffBeatValue = ( GapsFiltered( Pos ) + GapsFiltered( Pos + 1 ) ) / 2;
        
        GapsConfidence( ct1 ) = GapsFiltered( ct1 ) + ( OffBeatValue * 0.5 );        
    end
    
    GapPeaks = SortedGaps( find( GapsConfidence == max( GapsConfidence ) ) );
    
    IntervalFitness( (i + 1) - MinimumInterval ) = max( GapsConfidence );
    IntervalGap( (i+1) - MinimumInterval )       = GapPeaks( 1 );
    
end

% Find the top 50 possible BPMs that look interesting and compute the
% fitness of every interval around them
Temp = sort( IntervalFitness );
DoMoreWorkOn = find( IntervalFitness >= Temp( end-50 ) );
for ct1 = 1 : 50
    LookAt = DoMoreWorkOn( ct1 );
    
    if ( LookAt >= 10 )
        IntervalFitness( LookAt - 9 : LookAt - 1 ) = -1;
    end
    if ( LookAt <= (MaximumInterval - MinimumInterval + 1) - 10 )
        IntervalFitness( LookAt + 1 : LookAt + 9 ) = -1;
    end
end

for i = MinimumInterval : MaximumInterval
    
    if ( IntervalFitness( (i + 1) - MinimumInterval ) == -1 )
        
        Gaps = mod( Beats, i );
        ExtraGaps = Gaps + i;
        
        FullGaps = [ Gaps ExtraGaps ]';
        FullGaps = FullGaps(:);
        [ SortedGaps SortedIndex ] = sort( FullGaps );
        
        GapsFiltered = zeros( NumBeats, 1 );
        for ct1 = 1 : NumBeats
            Area = 0;
            
            Centre = SortedGaps( ct1 );
            
            Pos = ct1;
            PosVal = SortedGaps( Pos );
            while ( PosVal > Centre - HalfGapWindowSize )
                
                if Pos <= 1 
                    break;
                end
                xPos = SortedIndex( Pos );
                if ( xPos > size( Beats,1 ) ) 
                    xPos = xPos - size( Beats,1 );
                end
                Area = Area + ( BeatStrengths( xPos ) * GapWindow( PosVal - (Centre - HalfGapWindowSize) ) );
                Pos = Pos - 1;
                PosVal = SortedGaps( Pos );
            end
            
            Pos = ct1;
            PosVal = SortedGaps( Pos );
            while ( PosVal <= Centre + HalfGapWindowSize )
                
                if Pos >= NumBeats
                    break;
                end
                xPos = SortedIndex( Pos );
                if ( xPos > size( Beats,1 ) ) 
                    xPos = xPos - size( Beats,1 );
                end
                Area = Area + ( BeatStrengths( xPos ) * GapWindow( PosVal - (Centre - HalfGapWindowSize) ) );
                Pos = Pos + 1;
                PosVal = SortedGaps( Pos );
            end
            
            GapsFiltered( ct1 ) = Area;
            
        end
        
        % Need to take care of end cases better
        % Here we work out how much evidence there is to support each gap
        % by the GapFiltered value for each gap and a portion of the
        % GapFiltered value from offbeats.
        
        % Need to take care of end cases better
        GapsConfidence = zeros( NumBeats, 1 );
        for ct1 = 1 : NumBeats -1 
            
            OffbeatPos = SortedGaps( ct1 ) + round(i / 2);
            
            % We know the position of where an offbeat gap value would be but
            % we need to work out its index in the SortedGaps array
            Pos = ct1;
            PosVal = SortedGaps( Pos );
            while ( PosVal < OffbeatPos )
                if Pos >= NumBeats - 1
                    break;
                end
                Pos = Pos + 1;
                PosVal = SortedGaps( Pos );
            end
            
            % Not sure why I have this taking the average of the two nearest
            % gaps. Might give some improvement to accuracy, but most probably
            % pointless.
            OffBeatValue = ( GapsFiltered( Pos ) + GapsFiltered( Pos + 1 ) ) / 2;
            
            GapsConfidence( ct1 ) = GapsFiltered( ct1 ) + ( OffBeatValue * 0.5 );        
        end
        
        GapPeaks = SortedGaps( find( GapsConfidence == max( GapsConfidence ) ) );
        
        IntervalFitness( (i + 1) - MinimumInterval ) = max( GapsConfidence );
        IntervalGap( (i+1) - MinimumInterval )       = GapPeaks( 1 );
        
    end
end
disp( 'Brute forced the interval tests.' );

% Fit a polynomial to the fitness value in order to normalise the results
% to remove bias towards high BPMs
Y = IntervalFitness( 1:10:end );
Range = (MinimumInterval:MaximumInterval)';
X = Range(1:10:end);
NormalisedIntervalFitness = IntervalFitness - polyval( polyfit( X, Y, 3 ), Range );


% Now we do a bit of calculations to find the best interval, BPM and Gap
% value.
FitnessIndex = find( NormalisedIntervalFitness == max( NormalisedIntervalFitness ) );

Confidence   = max( NormalisedIntervalFitness );
Interval     = FitnessIndex(end) + (MinimumInterval - 1);
GapInSamples = IntervalGap( FitnessIndex(end) );
GapInSeconds = GapInSamples / Frequency;
BPM = ( Frequency / Interval ) * 60;
disp( 'Calcualted Gap and BPM.' );

if ( Confidence < 10 )
    error( 'Unable to confidently find BPM.' );
end


% Calculate the energy of each beat. It is simple the sum of the squared
% values of each sample in the waveform.
Position = round( GapInSamples ); 
WindowNum = 1;
AbsoluteEnergy = [];
Energy = [];
while ( Position + Interval < SongLength )
    
    Window = Mono( Position:(Position+round(Interval/2))-1 );
    AbsoluteEnergy( WindowNum ) = sum( Window .^ 2 );
    WindowNum = WindowNum + 1;
    
    Window = Mono( (Position+round(Interval/2)):(Position+Interval) );
    AbsoluteEnergy( WindowNum ) = sum( Window .^ 2 );
    WindowNum = WindowNum + 1;
    
    Position = Position + Interval;
end

Energy = AbsoluteEnergy ./ max( AbsoluteEnergy );
disp( 'Calculated Energy' );
% bar( Energy, 'r' );


% If the offbeats consistently have more energy than the beats themselves
% we have probably incorrectly computed the gap value. Shift the gap by
% half a beat.
if ( mean( Energy( 2:2:end ) ) > mean( Energy( 1:2:end ) ) + 0.001 )
    disp( ' *** Gap half beat out ***' );
    
    GapInSamples = GapInSamples + round(Interval / 2);
    GapInSeconds = GapInSamples / Frequency;
    Energy = Energy(2:end);
    
end



% Now compute a matrix of the similarity of each half beat to every other
% half beat.
BeatData = Energy;
SizeBeatData = size( BeatData, 2 );

SelfSimilarity = zeros(  SizeBeatData  );
for ct1 = 1 : SizeBeatData
    for ct2 = ct1 : SizeBeatData
        SelfSimilarity( ct1, ct2 ) = 1 - ( sqrt( sum( (BeatData( :, ct1 ) - BeatData( :, ct2 )).^2 ) ) / sqrt( size( BeatData, 1 ) ) );
        SelfSimilarity( ct2, ct1 ) = SelfSimilarity( ct1, ct2 );
    end
end
disp( 'Computed Self Similarity' );


% Now try and divide the music in bars of four notes. This requires picking
% the best position to start the division of bars. This is found by
% computing a self-similarity matrix for each possible bar start and taking
% the sharpest image.
X = 1;
PossibleBarStarts = zeros( BarSize, 1 );
BarSimilarities = [];
BarSizeInHalfBeats = BarSize * 2;
for FirstBarStart = 1 : 1 :  BarSizeInHalfBeats
    
    BarSimilarity = zeros( ceil( (SizeBeatData - ( BarSizeInHalfBeats - 1) - (BarSizeInHalfBeats-1)) / BarSizeInHalfBeats ) ); 
    Num1 = 1;
    Num2 = 1;
    
    % Produce self-similarity matrix.
    for ct1 = 1 : size( BarSimilarity, 1 )
        for ct2 = 1 : size( BarSimilarity, 2 )
            Pos1 = FirstBarStart + (ct1-1)*BarSizeInHalfBeats;
            Pos2 = FirstBarStart + (ct2-1)*BarSizeInHalfBeats;
            
            BarSimilarity( ct1, ct2 ) = mean( diag( SelfSimilarity( Pos1:Pos1 + ( BarSizeInHalfBeats - 1), ...
                Pos2:Pos2 + ( BarSizeInHalfBeats - 1) ) ) );
            BarSimilarity( ct2, ct1 ) = BarSimilarity( ct1, ct2 );
        end
    end
    
    % Compute the 'sharpness' as a measure of the mean difference between
    % the similarity of adjacent bars.
    BarSimilarity( 1, 1 ) = 0;
    BarSimilarities( :, :, FirstBarStart ) = BarSimilarity;
    Temp = BarSimilarity( 3:end-2, 3:end-2 );
    Temp = abs( diff( Temp ) );
    PossibleBarStarts( FirstBarStart ) = mean( Temp(:) );
end

% Now pick the best bar start. If it is on an offbeat, choose the next beat
% as the correct bar start.
BestBarStarts = find( PossibleBarStarts == max( PossibleBarStarts ) );
BarStart = BestBarStarts(1);
if ( mod( BarStart, 2 ) == 0 )
    BarStart = mod( BarStart + 1, BarSize );
end

BarSimilarity = BarSimilarities( :, :, BarStart );
disp( 'Calculated Bar Similarity.' );

% Now we know when the first bar occurs we can shift the Gap values,
% Similarity, Energy data etc to start at that point.
GapInSamples = GapInSamples + ((BarStart - 1)/2)*Interval;
GapInSeconds = GapInSamples / Frequency;
Energy = Energy( BarStart:end );
AbsoluteEnergy = AbsoluteEnergy( BarStart:end );
BeatData = BeatData( BarStart:end, BarStart:end );


% Now we want to use the self-similarity matrix of bars to compute a linear
% grouping of the music. First we find all the maximal cliques of similar
% bars and then use a greedy algorithm to choose a linear combination of
% these.

% Threshold the self-similarity matrix
Z = BarSimilarity;
Z(1,1) = 1;
Z( Z > 0.90 ) = 1;
Z( Z < 1 ) = 0;

% Find the maximalcliques
Y = maximalcliques( Z );

% Place the returned cliques into a matrix representation
X = [];
CurrentMax = 0;
for ct1 = 1 : size( Y, 2 )
    ThisClique = Y{ct1};
    CliqueSize = size( ThisClique, 2 );
    if ( CurrentMax < CliqueSize  )
        CurrentMax = CliqueSize;
    end
    
    X( ct1, 1:CurrentMax ) = [ ThisClique zeros( 1, CurrentMax - CliqueSize ) ];
end

% Greedily choose the biggest cliques. We make sure cliques whoch are very
% large are not chosen in order to keep the grouping interesting.
SimilarSections = zeros( size( BarSimilarity, 2), 1 );
NextSection = 1;
X2 = X;
while( any( X2(:) ~= 0 ) )
    [ Junk, Index ] = sort( sum( X2 ~= 0, 2 ) );

    % Find the biggest clique, which is not too big
    ct1 = 0;
    i = Index( end );
    SelectedClique = X2( i, : );
    while( (sum(SelectedClique ~= 0 ) > size( BarSimilarity, 2) * 0.5) && (size(Index, 1)-ct1 > 0) )
        disp( 'Ignoring a too large clique' );
        ct1 = ct1 + 1;
        i = Index( end - ct1 );
        SelectedClique = X2( i, : );
    end
    
    % Break out of the loop if only single element cliques are left.
    if ( sum(SelectedClique ~= 0 ) <= 1 )
        break;    
    end
    
    SimilarSections( SelectedClique( SelectedClique ~= 0 ) ) = NextSection;
    NextSection = NextSection + 1;

    % Remove the chosen elements from any remaining cliques
    for ct1 = 1 : size( SelectedClique, 2 )
        NodeInClique = SelectedClique( ct1 );
        X2( X2 == NodeInClique ) = 0;          
    end
end

% Now give any remaining bars their own sections.
Next = max( SimilarSections ) + 1;
for ct1 = 1 : size( SimilarSections, 1 )
    if ( SimilarSections( ct1 ) == 0 )
        SimilarSections( ct1 ) = Next;
        Next = Next + 1;
    end
end

% For each beat we store which section it is in.
SimilarityOnBeats = zeros( size( Energy, 2 ) );
for ct1 = 1 : size( SimilarSections, 1 )
    Range = ( 1 + (ct1 - 1)*BarSizeInHalfBeats : 1 + (ct1*BarSizeInHalfBeats) -1 );
    SimilarityOnBeats( Range ) = SimilarSections( ct1 );
end
disp( 'Divided song into groups.' );


% Extract pauses from the music. Simply find bars which are very quiet.
PauseThreshold = 150;
Temp = find( AbsoluteEnergy >= PauseThreshold );
FirstMajorEnergy  = Temp(1);
LastMajorEnergy = Temp(end);
Pauses = [];

for ct1 = 1 : size( BarSimilarity, 1 )
    Range = ( 1 + (ct1 - 1)*BarSizeInHalfBeats : 1 + (ct1*BarSizeInHalfBeats) -1 );
    BarAbsoluteEnergy = AbsoluteEnergy( Range );

    if ( prctile( BarAbsoluteEnergy, 65 ) < PauseThreshold && Range(1) > FirstMajorEnergy && Range(end) < LastMajorEnergy )
        Pauses = [ Pauses ; [ ((Range(1)-1)/2)-1, BarSize * (Interval / Frequency ) ] ];        
    end
end
disp( 'Found pauses.' );


% Find good positions for freeze arrows. This is done by finding areas in
% the song with no large onsets.
Z = SmoothedData ./ max( SmoothedData );
A = gradient( Z );

Freezes = [];
FreezeStarted = 0;
for ct1 = FirstMajorEnergy : LastMajorEnergy
    WaveformStart = round( GapInSamples + ((ct1 - 1)/2)*Interval );
    WaveformEnd   = round( GapInSamples + ((ct1)/2)*Interval - 1 );    
    
    if ( ~isempty( Pauses ) & any( ( ((Pauses( :, 1 )+1).*2)+1  <= ct1  ) & ( ((Pauses( :, 1 )+1).*2)+BarSizeInHalfBeats+1  >= ct1 ) ) )
        FreezeStarted = 0;
        continue;
    end
    
    if ( max( A(WaveformStart:WaveformEnd) ) < 8e-5 && AbsoluteEnergy( ct1 ) < 3000 && AbsoluteEnergy( ct1 ) > 0 )
        if ( FreezeStarted == 0 )
            FreezeStarted = ( floor( ct1 / 2 ) * 2 ) - 1;
        end
    else
        if ( FreezeStarted > 0 )
            if ( FreezeStarted < ct1-6 )
                FreezeEnd = ct1;
                if ( mod( FreezeEnd, 2 ) == 0 )
                    FreezeEnd = FreezeEnd - 1;    
                end
                Freezes = [ Freezes ; FreezeStarted FreezeEnd ];
            end
        end
        FreezeStarted = 0;
    end
end

% Freezes longer than 8 half beats we deal with after placing the rest of
% the arrows.
LongFreezes = [];
FreezeBeats = zeros( size( Energy ) );
for ct1 = 1 : size( Freezes, 1 )
    if ( Freezes( ct1, 2 ) - Freezes( ct1, 1 ) < 8 )
        FreezeBeats( Freezes( ct1, 1 ):Freezes( ct1, 2 ) ) = 1;
    else
        LongFreezes = [ LongFreezes ; Freezes( ct1, 1 ), Freezes( ct1, 2 ) ];           
    end
end
disp( 'Found freeze arrow positions.' );


% Here the patterns of arrows are created.

% Set variables which do not change when generating each set of arrows
DifficultyOffbeatModifier = [ 0 0 0 0.2 0.5 0.6 0.7 0.8 0.9 ];
DifficultyRatings = [ 107 137 170 194 228 262 305 366 ];
NumBars = size( BarSimilarity, 2 );


% The Allowable moves matrix stores which arrows can be placed depending
% on the position of the players feet and which foot they will move next.
AllowableMoves = [];
%                            [    Left    ] [   Right   ] [ Index  ]
AllowableMoves( :, :, 1 )  = [ 1  1  1  0  ; 0  1  1  1  ; 1 0 0 2 ];
AllowableMoves( :, :, 2 )  = [ 1  1  1  0  ; .1 1  0  1  ; 0 0 1 2 ];
AllowableMoves( :, :, 3 )  = [ 1  1  0  .1 ; 0  1  1  1  ; 1 0 2 0 ];
AllowableMoves( :, :, 4 )  = [ 1  1  1  0  ; .1 0  1  1  ; 0 1 0 2 ];
AllowableMoves( :, :, 5 )  = [ 1  0  1  .1 ; 0  1  1  1  ; 1 2 0 0 ];
AllowableMoves( :, :, 6 )  = [ 1  1  0  .1 ; .1 0  1  1  ; 0 1 2 0 ];
AllowableMoves( :, :, 7 )  = [ 1  0  1  .1 ; .1 1  0  1  ; 0 2 1 0 ];
AllowableMoves( :, :, 8 )  = [ 1  0  1  0  ; 0  1  0  0  ; 0 2 0 1 ];
AllowableMoves( :, :, 9 )  = [ 1  1  0  0  ; 0  0  1  0  ; 0 0 2 1 ];
AllowableMoves( :, :, 10 ) = [ 0  0  1  0  ; 0  1  0  1  ; 2 0 1 0 ];
AllowableMoves( :, :, 11 ) = [ 0  0  1  0  ; 0  0  1  1  ; 2 1 0 0 ];


EnergyDiff = diff( AbsoluteEnergy );
EnergyDiff = [ 0 EnergyDiff ];

ArrowTrackSize = size( BarSimilarity, 1 ) * MaxArrowsPerBar;
ArrowTracks = [];
FootRatings = [];

% For each of the three difficulty levels we will produce arrows for.
for ArrowSet = 1 : 3
    UserDifficultyRating = ChosenDifficultyRatings( ArrowSet );
    
    OffbeatModifier = DifficultyOffbeatModifier( UserDifficultyRating );
    AvgArrowsPerLevel = mean( [ DifficultyRatings 420 ; 0 DifficultyRatings ] );
    
    NumArrows = AvgArrowsPerLevel( UserDifficultyRating );
    ArrowsPerBar = NumArrows / NumBars;
    ModdedEnergy = Energy;
    ModdedEnergy( 2:2:end ) = ModdedEnergy( 2:2:end ) .* OffbeatModifier;
    
    % Work out the spread of the arrows based on energy of each bar of
    % music.
    FullBarEnergy = [];
    for ct1 = 1 : size( BarSimilarity, 1 )
        Range = ( 1 + (ct1 - 1)*BarSizeInHalfBeats : 1 + (ct1*BarSizeInHalfBeats) -1 );
        FullBarEnergy(ct1) = mean( ModdedEnergy( Range ) );
    end
    
    % Normalise this and ensure each bar does not have too many or too few
    % arrows.
    for ct0 = 1 : 10
        FullBarEnergy = FullBarEnergy ./ ( sum( FullBarEnergy ) / NumArrows );
        
        for ct1 = 3 : size( BarSimilarity, 1 )
            if ( all( round( FullBarEnergy( ct1-2:ct1 ) ) < 1 ) ) 
                FullBarEnergy(ct1) = 1;
            end
            if ( all( round( FullBarEnergy( ct1-2:ct1 ) ) >= 7 ) ) 
                FullBarEnergy(ct1) = 6;
            end
            if ( round( FullBarEnergy( ct1 ) ) > 8 )
                FullBarEnergy(ct1) = 8;    
            end
        end
        
    end
    
    CurrentFoot = 0;
    FootPlacement = [ 1 0 0 2 ];
    
    ArrowTrack = zeros( ArrowTrackSize, 4 );
    InFreeze = false;
    
    JumpThreshold = 0.95 - ( UserDifficultyRating * 0.03 );
    
    %  For each group we have, compute an arrow pattern for that group
    SectionArrowData = zeros( BarSizeInHalfBeats, 4,  max( SimilarSections ) ) - 1;
    for ct1 = 1 : max( SimilarSections )
        CurrentFoot = 0;
        FootPlacement = [ 1 0 0 2 ];
        
        % work out average energy and number of notes per bar in this section
        TempModdedEnergy = ModdedEnergy( SimilarityOnBeats == ct1 );
        TempEnergy = Energy( SimilarityOnBeats == ct1 );
        TempFreezes = FreezeBeats( SimilarityOnBeats == ct1 );
        
        BarModdedEnergy = zeros( BarSizeInHalfBeats, 1 );
        BarEnergy = zeros( BarSizeInHalfBeats, 1 );
        for ct2 = 1 : BarSizeInHalfBeats
            BarModdedEnergy( ct2 ) = mean( TempModdedEnergy( ct2:BarSizeInHalfBeats:end ) );
            BarEnergy( ct2 ) = mean( TempEnergy( ct2:BarSizeInHalfBeats:end ) );
            BarFreezes( ct2 ) = mean( TempFreezes( ct2:BarSizeInHalfBeats:end ) );
        end
        
        NumArrows = round( mean( FullBarEnergy( SimilarSections == ct1 ) ) );
        PlaceArrow = zeros( BarSizeInHalfBeats, 1 );
        NumArrowsToHave = min( NumArrows, sum( BarModdedEnergy > 0 ) );
        [ Temp Index ] = sort( BarModdedEnergy );
        PlaceArrow( Index( end - (NumArrowsToHave - 1):end ) ) = 1;
        
        % Now compute the arrows for that group
        FreezeOn = false;
        PrevBeatEnergy = 0.4;
        BarArrows = zeros( BarSizeInHalfBeats, 4 );
        for ct2 = 1 : BarSizeInHalfBeats
            if ( ~FreezeOn & BarFreezes( ct2 ) >= 0.5 )
                    FreezeOn = true;
                
                    if ( CurrentFoot == 0 )
                        % Place a left or right arrow to get started.
                        CurrentFoot = ceil(rand(1) * 2); 
                        if ( CurrentFoot == 1 )
                            ArrowType = 1;   
                        else
                            ArrowType = 4;
                        end
                    else      
                        % Find allowable moves pattern for current foot
                        % placement.
                        CurrentFoot = mod( CurrentFoot, 2 ) + 1;

                        PossibleMoves = [ 0 0 0 0 ];
                        for ct3 = 1 : size( AllowableMoves, 3 )
                            if ( AllowableMoves( 3, :, ct3 ) == FootPlacement )
                                PossibleMoves = AllowableMoves( CurrentFoot, :, ct3 );
                            end
                        end
                        
                        if ( PossibleMoves == [ 0 0 0 0 ] )
                            error( 'No possible moves found' );    
                        end
                        
                        % Calculate Probabilities of new move.
                        ProbMoves = cumsum( PossibleMoves ./ sum( PossibleMoves ) );
                        
                        % Choose arrow based on probabilities
                        Temp = find( ProbMoves >= rand(1) );
                        ArrowType = Temp(1);
                        
                    end
                    
                    NewArrow = [ 0 0 0 0 ];
                    NewArrow( ArrowType ) = 2;
                    BarArrows( ct2, : ) = NewArrow;
                    
                    FootPlacement( FootPlacement == CurrentFoot ) = 0;
                    FootPlacement( NewArrow > 0 ) = CurrentFoot;
                    
                    FreezeArrow = ArrowType;
                    
             elseif ( FreezeOn & mod( ct2, 2 ) == 1 & ( BarFreezes( ct2 ) < 0.5  | ct2 == BarSizeInHalfBeats-1 ) )
                 
                    FreezeOn = false;
                    NewArrow = [ 0 0 0 0 ];
                    NewArrow( FreezeArrow ) = 3;
                    BarArrows( ct2, : ) = NewArrow;
                 
             elseif ( PlaceArrow( ct2 ) == 1 & ~( FreezeOn & ( mod(ct2,2) == 0 | UserDifficultyRating <= 3 | (UserDifficultyRating <= 6 & mod( ct2, 4 ) == 1) ) ) )
                if ( ~FreezeOn & (BarEnergy(ct2) > PrevBeatEnergy + 0.2) & (BarEnergy(ct2) > JumpThreshold) & mod( ct2, 2 ) == 1 )  %%%% IMPROVE JUMP SELECTION STUFF %%%%
                    % A lot of energy so place a double jump

                    
                    JumpType = ceil( rand(1) * 6 );
                    switch( JumpType )
                        case 1
                            BarArrows( ct2, : ) = [ 0 1 1 0 ];
                            % For this double jump foot placement
                            % depends on the previous foot placement.
                            if ( FootPlacement( 3 ) == 1 || FootPlacement( 2 ) == 2 )
                                FootPlacement = [ 0 1 2 0 ];
                            else
                                FootPlacement = [ 0 2 1 0 ];
                            end
                        case 2
                            BarArrows( ct2, : ) = [ 1 0 0 1 ];
                            FootPlacement = [ 1 0 0 2 ];
                        case 3
                            BarArrows( ct2, : ) = [ 1 1 0 0 ];
                            FootPlacement = [ 1 2 0 0 ];
                        case 4
                            BarArrows( ct2, : ) = [ 0 0 1 1 ];
                            FootPlacement = [ 0 0 1 2 ];
                        case 5
                            BarArrows( ct2, : ) = [ 1 0 1 0 ];
                            FootPlacement = [ 1 0 2 0 ];
                        case 6
                            BarArrows( ct2, : ) = [ 0 1 0 1 ];
                            FootPlacement = [ 0 1 0 2 ];
                    end
                    CurrentFoot = 0;
                else
                    % Place a normal arrow.
                    if ( CurrentFoot == 0 )
                        % Place a left or right arrow to get started.
                        CurrentFoot = ceil(rand(1) * 2); %%%%%%% FIX RAND %%%%%
                        if ( CurrentFoot == 1 )
                            ArrowType = 1;   
                        else
                            ArrowType = 4;
                        end
                    elseif ( CurrentFoot > 0 & ct2 > 1 & abs( BarEnergy( ct2-1 ) - BarEnergy( ct2 ) ) < 0.02 )    
                        % Place the same arrow as last time, and
                        % keeps the same current foot as last time.
                        
                        % Leave Current Foot and Arrow Type unchanged.
                    else      
                        % Find allowable moves pattern for current foot
                        % placement.
                        CurrentFoot = mod( CurrentFoot, 2 ) + 1;

                        PossibleMoves = [ 0 0 0 0 ];
                        for ct3 = 1 : size( AllowableMoves, 3 )
                            if ( AllowableMoves( 3, :, ct3 ) == FootPlacement )
                                PossibleMoves = AllowableMoves( CurrentFoot, :, ct3 );
                            end
                        end
                        
                        if ( PossibleMoves == [ 0 0 0 0 ] )
                            error( 'No possible moves found' );    
                        end
                        
                        % Calculate Probabilities of new move.
                        ProbMoves = cumsum( PossibleMoves ./ sum( PossibleMoves ) );
                        
                        % Choose arrow based on probabilities
                        Temp = find( ProbMoves >= rand(1) );
                        ArrowType = Temp(1);
                        
                    end
                    
                    NewArrow = [ 0 0 0 0 ];
                    NewArrow( ArrowType ) = 1;
                    BarArrows( ct2, : ) = NewArrow;
                    
                    FootPlacement( FootPlacement == CurrentFoot ) = 0;
                    FootPlacement( NewArrow > 0 ) = CurrentFoot;
                    
                end
            end
            
            if ( mod( ct2, 2 ) == 1 )
                PrevBeatEnergy = BarEnergy( ct2 );    
            end
        end 
        
        SectionArrowData( :, :, ct1 ) = BarArrows;        
    end
    
    
    
    
    
    FreezeOn = false;
    FreezeArrow = -1;
    for ct1 = 1 : size( BarSimilarity, 1 )
        % This section has already had its arrows chosen, so just repeat
        % them but with subtle modifications, eg. swap left/right or
        % up/down.
        BarSection = SimilarSections( ct1 );
        ArrowIndex = (((1 + (ct1 - 1)*BarSizeInHalfBeats)-1)*(MaxArrowsPerBar/BarSizeInHalfBeats))+1;
        
        
        % First check if we should have a pause here, if so write out -1
        % for arrows instead
        if ( ~isempty( Pauses ) & any( Pauses( :, 1 )  + 2 == ((ct1-1)*BarSize)+1 ) )
            BarArrows( :, : ) = -1;    
        else
            
            % No pause so use data from sections
            if ( ct1 > 1 && SimilarSections( ct1 - 1 ) == BarSection )
                % Last bar was in the same section so alter the repeated arrows
                ChangeLeftRightProbability = 0.5;
                ChangeUpDownProbability = 0.5;
            else
                % Last bar was a different section so make in unlikely that the repeated arrows will be changed.
                ChangeLeftRightProbability = 0.00;
                ChangeUpDownProbability = 0.00;
            end
            
            BarArrows = SectionArrowData( :, :, BarSection );
            if ( rand(1) > ChangeLeftRightProbability )
                % Swap left and right arrows            
                Temp = BarArrows( :, 1 );
                BarArrows( :, 1 ) = BarArrows( :, 4 ); 
                BarArrows( :, 4 ) = Temp;
            end
            if ( rand(1) > ChangeUpDownProbability )
                % Swap up and down arrows            
                Temp = BarArrows( :, 2 );
                BarArrows( :, 2 ) = BarArrows( :, 3 ); 
                BarArrows( :, 3 ) = Temp;
            end
            
        end
        
        % Freeze arrow stuff
        if ( ~isempty( LongFreezes ))
            for ct2 = 1 : BarSizeInHalfBeats
                CurrentBeat = ( (ct1-1)*BarSizeInHalfBeats ) + ct2;
                
                if ( FreezeOn )
                    % Stop other arrows while freeze arrow going past.
                    if ( UserDifficultyRating <= 3 )
                        BarArrows( ct2, : ) = 0;    
                    end
                    if ( UserDifficultyRating <= 6 & mod( CurrentBeat, 4 ) == 1 )
                        BarArrows( ct2, : ) = 0;    
                    end
                    if ( mod( CurrentBeat, 2 ) == 0 )
                        BarArrows( ct2, : ) = 0;    
                    end
                    
                    % Stop any jumps occuring
                    if ( sum( BarArrows( ct2, : ) > 0 ) > 1 )
                        BarArrows( ct2, : ) = 0;    
                    end
                end
                
                if ( any( LongFreezes( :, 2 ) == CurrentBeat ) & FreezeOn )
                    BarArrows( ct2, FreezeArrow ) = 3;
                    FreezeOn = false;
                    FreezeArrow = -1;
                end
                if ( any( LongFreezes( :, 1 ) == CurrentBeat ) & ~FreezeOn )
                    FreezeOn = true;
                    FreezeArrow = ceil( rand(1) * 4 );
                    Temp = BarArrows( ct2, : );
                    Temp( Temp == 1 ) = 0;
                    BarArrows( ct2, : ) = Temp;
                    BarArrows( ct2, FreezeArrow ) = 2;
                end
            end 
        end
        
        
        for ct2 = 1 : BarSizeInHalfBeats
            Index = ArrowIndex + (ct2 - 1) * ( MaxArrowsPerBar / BarSizeInHalfBeats );    
            ArrowTrack( Index, : ) = BarArrows( ct2, : );
        end
        
    end
    
    for ct1 = 3 : 2 : size( ArrowTrack, 1 ) - 1
        % If this is a jump
        if ( sum( ArrowTrack( ct1, : ) == 1 ) > 1 )
            % remove any offbeats around it
            ArrowTrack( ct1 - 1, : ) = 0;
            ArrowTrack( ct1 + 1, : ) = 0;
        end
    end
    
    NumArrows = sum( ArrowTrack(:) > 0 );
    FootRating = 9 - sum( DifficultyRatings > NumArrows );
    disp( [ 'Foot Rating: ' int2str( FootRating ) ] );
    
    FootRatings( ArrowSet ) = FootRating;
    ArrowTracks( :, :, ArrowSet ) = ArrowTrack;
    
end
disp( 'Created arrow patterns for each difficulty level.' );

% Now we need to output the arrow track to a step file.

% Output step file in .dwi format
fid = fopen ( strcat( OutputDirectory, StepFilename, '.dwi' ), 'wt');

fprintf( fid, '#TITLE:%s;\n', FileName );
fprintf( fid, '#ARTIST:The Dancing Monkeys Project;\n' );
fprintf( fid, '#GAP:%f;\n', GapInSeconds * 1000 );
fprintf( fid, '#BPM:%f;\n', BPM );
fprintf( fid, '#FILE:%s;\n', MusicFullFilename );

% TODO: Fix DWI to use MaxArrowsPerBar

if ( ~ isempty( Pauses ) )
    fprintf( fid, '#FREEZE:' );
    for ct1 = 1 : size( Pauses, 1 )
        if ( ct1 > 1 )
            fprintf( fid, ',' );
        end
        fprintf( fid, '%d=%d', (( Pauses( ct1, 1 ) - (ct1-1)*BarSize )) * BarSize, round( Pauses( ct1, 2 )*1000 ) );
    end
    fprintf( fid, ';\n' );
end
fprintf( fid, '\n// --- Arrows ---\n');

DWIDifficultyNames = { 'BASIC', 'ANOTHER', 'MANIAC' };
for ArrowSet = 1 : 3
    FootRating = FootRatings( ArrowSet );
    ArrowTrack = ArrowTracks( :, :, ArrowSet );
    
    fprintf( fid, '#SINGLE:%s:%d:\n', DWIDifficultyNames{ ArrowSet }, FootRating );

    % Assuming MaxArrowsPerBar == 8
    for ct1 = 1 : size( ArrowTrack, 1 )
        
        if ( ArrowTrack( ct1, : ) == [ -1 -1 -1 -1 ] )
            % Don't write out any arrows as we have a pause.    
            continue;    
        end
        ThisBeat = ArrowTrack( ct1, : ) > 0;
        
        if ThisBeat == [ 0 0 0 0 ]
            Character = '0';
        elseif ThisBeat == [ 1 0 0 0 ]
            Character = '4';
        elseif ThisBeat == [ 0 1 0 0 ]
            Character = '2';
        elseif ThisBeat == [ 0 0 1 0 ]
            Character = '8';
        elseif ThisBeat == [ 0 0 0 1 ]
            Character = '6';
        elseif ThisBeat == [ 1 0 0 1 ]
            Character = 'B';
        elseif ThisBeat == [ 0 1 1 0 ]
            Character = 'A';
        elseif ThisBeat == [ 0 0 1 1 ]
            Character = '9';
        elseif ThisBeat == [ 0 1 0 1 ]
            Character = '3';
        elseif ThisBeat == [ 1 0 1 0 ]
            Character = '7';
        elseif ThisBeat == [ 1 1 0 0 ]
            Character = '1';
        end
        fprintf( fid, '%c', Character );
        
        % Freeze Arrows
        ThisBeat = ( ArrowTrack( ct1, : ) == 2 );
        if ( any( ThisBeat ) )
            if ThisBeat == [ 1 0 0 0 ]
                Character = '4';
            elseif ThisBeat == [ 0 1 0 0 ]
                Character = '2';
            elseif ThisBeat == [ 0 0 1 0 ]
                Character = '8';
            elseif ThisBeat == [ 0 0 0 1 ]
                Character = '6';
            end
            fprintf( fid, '!%c', Character );    
        end
        
    end
    fprintf( fid, ';\n\n' );
end

fclose( fid );
disp( 'Created .dwi step file.' );


% Output step file in .sm format
fid = fopen ( strcat( OutputDirectory, StepFilename, '.sm' ), 'wt');

fprintf( fid, '#TITLE:%s;\n', FileName );
fprintf( fid, '#ARTIST:The Dancing Monkeys Project;\n' );
fprintf( fid, '#OFFSET:%f;\n', -( GapInSeconds + StepFileFudgeFactor ) );
fprintf( fid, '#BPMS:0=%f;\n', BPM );
fprintf( fid, '#MUSIC:%s;\n', OutputFile );

if ( ~ isempty( Pauses ) )
    fprintf( fid, '#STOPS:' );
    for ct1 = 1 : size( Pauses, 1 )
        if ( ct1 > 1 )
            fprintf( fid, ',' );
        end
        fprintf( fid, '%f=%f', (Pauses( ct1, 1 ) - (ct1-1)*BarSize), Pauses( ct1, 2 ) );
    end
    fprintf( fid, ';\n' );
end
fprintf( fid, '\n// --- Arrows ---\n');

DifficultyNames = { 'Basic' 'easy' ; 'Standard' 'medium' ; 'Heavy' 'hard' };
for ArrowSet = 1 : 3
    FootRating = FootRatings( ArrowSet );
    ArrowTrack = ArrowTracks( :, :, ArrowSet );
    
    fprintf( fid, '#NOTES:\n\tdance-single:\n\t%s:\n\t%s:\n\t%d:\n\t:\n' ...
        , DifficultyNames{ ArrowSet, 1 }, DifficultyNames{ ArrowSet, 2 }, FootRating );
    
    for ct1 = 1 : size( ArrowTrack, 1 )
        
        if ( ArrowTrack( ct1, : ) == [ -1 -1 -1 -1 ] )
            % Don't write out any arrows as we have a pause.    
            continue;    
        end
        fprintf( fid, '%d%d%d%d\n', ArrowTrack( ct1, : ) );
        
        if ( mod( ct1, MaxArrowsPerBar ) == 0 )
            fprintf( fid, ',\n');
        end
    end
    
end

fclose( fid );
disp('Created .sm step file.');





% Output the results to the screen.
disp( 'Results: ' );
disp( '  Song name:' );
disp( FileName );
disp( '  BPM:' );
disp( BPM );
disp( '  Gap:' );
disp( GapInSeconds );
disp( '  Confidence:' );
disp( Confidence );

toc;