# Copyright 2000-2009 JetBrains s.r.o.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# @author: Roman Chernyatchik
######################
require "teamcity/rakerunner_consts"

module Rake
  module TeamCity
    module MessageFactory
      ATTR_NAME = "name"
      #TODO Extract other attributes - message, duration, etc

      MSG_BLOCK_TYPES = {
         #      :build => "Build"               # BLOCK_TYPE_BUILD
        :progress => "$BUILD_PROGRESS$",       # BLOCK_TYPE_PROGRESS
        :test => "$TEST_BLOCK$",               # BLOCK_TYPE_TEST
        :test_suite => "$TEST_SUITE$",         # BLOCK_TYPE_TEST_SUITE
        :compilation => "$COMPILATION_BLOCK$", # BLOCK_TYPE_COMPILATION
        :target => "$TARGET_BLOCK$",           # BLOCK_TYPE_TARGET
        :task => "rakeTask"
      }

      MSG_STATUS_TYPES = {
        :warning => "WARNING",
        :error => "ERROR"
      }

      @@fake_time_enabled = ::Rake::TeamCity.is_fake_time_enabled?()
      @@fake_stacktrace = ::Rake::TeamCity.is_fake_stacktrace_enabled?()
      @@fake_location_url = ::Rake::TeamCity.is_fake_location_url_enabled?()
      @@fake_error_message = ::Rake::TeamCity.is_fake_error_msg_enabled?()

      def self.create_suite_started(suite_name, location_url = nil)
        "##teamcity[testSuiteStarted #{ATTR_NAME}='#{replace_escaped_symbols(suite_name)}'#{create_info_location(location_url)} #{create_info_timestamp()}]"
      end

      def self.create_suite_finished(suite_name)
        "##teamcity[testSuiteFinished #{ATTR_NAME}='#{replace_escaped_symbols(suite_name)}' #{create_info_timestamp()}]"
      end

      def self.create_tests_count(int_count)
        "##teamcity[testCount count='#{int_count}' #{create_info_timestamp()}]"
      end

      def self.create_test_started(test_name, location_url = nil)
        "##teamcity[testStarted name='#{replace_escaped_symbols(test_name)}' captureStandardOutput='true'#{create_info_location(location_url)} #{create_info_timestamp()}]"
      end

      # Duration in millisec
      def self.create_test_finished(test_name, duration_ms)
        duration_string =  @@fake_time_enabled ? "##DURATION##" : (duration_ms > 0 ? duration_ms : 0).to_s
        "##teamcity[testFinished name='#{replace_escaped_symbols(test_name)}' duration='#{duration_string}' #{create_info_timestamp()}]"
      end

      def self.create_test_output_message(test_name, is_std_out, out_text)
        "##teamcity[testStd#{is_std_out ? "Out" : "Err"} name='#{replace_escaped_symbols(test_name)}' out='#{replace_escaped_symbols(out_text)}' #{create_info_timestamp()}]"
      end

      def self.create_test_failed(test_name, message, stacktrace)
        stacktrace = format_stacktrace_if_neded(message, stacktrace)
        "##teamcity[testFailed name='#{replace_escaped_symbols(test_name)}' message='#{replace_escaped_symbols(message)}'#{create_info_stacktrace(stacktrace)} #{create_info_timestamp()}]"
      end

      def self.create_test_error(test_name, message, stacktrace)
        stacktrace = format_stacktrace_if_neded(message, stacktrace)
        "##teamcity[testFailed name='#{replace_escaped_symbols(test_name)}' message='#{replace_escaped_symbols(message)}'#{create_info_stacktrace(stacktrace)} error='true' #{create_info_timestamp()}]"
      end

      def self.create_test_ignored(test_name, message, stacktrace = nil)
        "##teamcity[testIgnored name='#{replace_escaped_symbols(test_name)}' message='#{replace_escaped_symbols(message)}'#{create_info_stacktrace(stacktrace)} #{create_info_timestamp()}]"
      end

      # This message should show progress on buildserver and can be
      # ignored by IDE tests runners
      def self.create_progress_message(message)
        # This kind of message doesn't support timestamp attribute
        "##teamcity[progressMessage '#{replace_escaped_symbols(message)}']"
      end

      # This message should show custom build status on buildserver and can be
      # ignored by IDE tests runners
      def self.create_build_error_report(message)
        "##teamcity[buildStatus status='ERROR' text='#{replace_escaped_symbols(message)}' #{create_info_timestamp()}]"
      end

      def self.create_msg_error(message, stacktrace = nil)
        if @@fake_stacktrace
          stacktrace = stacktrace.nil? ? nil : "##STACK_TRACE##"
        end
        if @@fake_error_message
          message = message.nil? ? nil : "##MESSAGE##"
        end
        details = (stacktrace.nil?) ? "" : " errorDetails='#{replace_escaped_symbols(stacktrace)}'";
        "##teamcity[message text='#{replace_escaped_symbols(message)}' status='#{MSG_STATUS_TYPES[:error]}'#{details} #{create_info_timestamp()}]"
      end

      def self.create_msg_warning(message)
        "##teamcity[message text='#{replace_escaped_symbols(message)}' status='#{MSG_STATUS_TYPES[:warning]}' #{create_info_timestamp()}]"
      end

      def self.create_open_target(msg)
        "##teamcity[blockOpened name='#{replace_escaped_symbols(msg)}' type='#{MSG_BLOCK_TYPES[:target]}' #{create_info_timestamp()}]"
      end

      def self.create_close_target(msg)
        "##teamcity[blockClosed name='#{replace_escaped_symbols(msg)}' type='#{MSG_BLOCK_TYPES[:target]}' #{create_info_timestamp()}]"
      end

      ###################################################################
      ###################################################################
      ###################################################################

      def self.replace_escaped_symbols(text)
        copy_of_text = String.new(text)

        copy_of_text.gsub!(/\|/, "||")

        copy_of_text.gsub!(/'/, "|'")
        copy_of_text.gsub!(/\n/, "|n")
        copy_of_text.gsub!(/\r/, "|r")
        copy_of_text.gsub!(/\]/, "|]")

        copy_of_text
      end

      private
      def self.create_info_location(location_url)
        if @@fake_location_url
          location_url = location_url.nil? ? nil : "##LOCATION_URL##"
        end
        location_url ? " location='#{replace_escaped_symbols(location_url)}'" : ""
      end

      def self.create_info_timestamp()
        "timestamp='#{replace_escaped_symbols(convert_time_to_java_simple_date(Time.now))}'"
      end

     def self.create_info_stacktrace(stacktrace)
       if @@fake_stacktrace
         stacktrace = stacktrace.nil? ? nil : "##STACK_TRACE##"
       end

       stacktrace.nil? ? "" : " details='#{replace_escaped_symbols(stacktrace)}'"
      end

      def self.format_stacktrace_if_neded message, stacktrace
        if Rake::TeamCity.is_in_buildserver_mode()
          # At current moment TC doesn't extract message from corresponding attribute.
          # see [TW-6270] http://jetbrains.net/tracker/workspace?currentIssueId=TW-6270
          message + "\n\nStack trace:\n" + stacktrace
        else
          stacktrace
        end
      end

      protected
      def self.convert_time_to_java_simple_date(time)
        if @@fake_time_enabled
          return "##TIME##"
        end
        gmt_offset = time.gmt_offset
        gmt_sign = gmt_offset < 0 ? "-" : "+"
        gmt_hours = gmt_offset.abs / 3600
        gmt_minutes = gmt_offset.abs % 3600

        millisec = time.usec == 0 ? 0 : time.usec / 1000

        #Time string in Java SimpleDateFormat
        sprintf("#{time.strftime("%Y-%m-%d'T'%H:%M:%S.")}%03d#{gmt_sign}%02d%02d", millisec, gmt_hours, gmt_minutes)
      end
    end
  end
end