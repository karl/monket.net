# Change list
#
# 15.05.2009
#   Fully rewriten using RubyMine's ServiceMessage API. Also semantics was changed:
#      * steps should be reported as tests
#      * scenarios, features as suites
#   New cucumber 0.3.6 API was used (including --expand) option
#
# 14.05.2009
#  Initial version was given from http://github.com/darrell/cucumber_teamcity/tree/master
#  Thanks to Darrell Fuhriman (darrell [at] garnix.org)
require 'cucumber/formatter/console'
require 'fileutils'

$: << File.expand_path(File.dirname(__FILE__) + '/../../lib/')
require 'teamcity/runner_common'
require 'teamcity/utils/service_message_factory'
require 'teamcity/utils/runner_utils'
require 'teamcity/utils/url_formatter'

class JBTeamCityFormatter < ::Cucumber::Ast::Visitor
      include FileUtils
      include ::Cucumber::Formatter::Console
      include Rake::TeamCity::RunnerCommon
      include Rake::TeamCity::RunnerUtils
      include Rake::TeamCity::Utils::UrlFormatter

      def initialize(step_mother, io, options, delim='|')
        super(step_mother)
        # io - ignored

        @options = options

        # true when we are in context of Background block
        @in_background = nil

        # true when we are in context of scenario_outline Examples
        @in_outline_examples = nil

        # scenarious are provided as feature_elements. This helps to
        # understand either current feature otline example ot not
        # TODO: remove it. Extend @current_example_or_feature_elems_stack
        # to save this info istead of just name
        @in_outline_scenario_stack = []

        # cucumber reports only names for fake row-based scenarios
        # this is used for closing previous suite when new fake scenario has
        # started or whole example has finished
        @previous_examples_scenario_outline = nil

        # tags for current holder : feature, scenario or step
        @tags_holder_stack = []

        # stack of active (unfinished) feature_elements: scenario, scenario_outline, example
        @current_example_or_feature_elems_stack = []

        # current feature name - is used for closing feature block
        @current_feature_name = nil

        # is used for counting execution duration of steps
        @current_step_start_time = nil

        # for console runner methods
        @io = $stdout
        @delim = delim
        @indent = 0
      end

##################################################
# For tags gathering
      def visit_tag_name(tag_name)
        tag = format_string("@#{tag_name}", :tag)
        if @tags_holder_stack.empty?
          print_tags_collection([tag])
        else
            @tags_holder_stack.last.add_tag(tag)
        end
        super
      end

#### Features
      # @Processes: features
      # Will be invoked before all features.
      # we will use this method for runner initialization and
      # test count reporting
      def visit_features(features)
        # Setups Test runner's MessageFactory
        set_message_factory(Rake::TeamCity::MessageFactory)

        # TODO - step count, but it seems it is unreal using current cucmber API.
        super
        print_summary(features)
      end

      # @Processes: tags, feature name, background and all feature elements
      # we use to close feature in the end (after all elements will be processed)
      def visit_feature(feature)
        # this stack allows us to show tags under corresponding
        # feature node. This is necessarry due to cucumber's
        # AST and visitor API specific
        register_tags_holder

        # each feature file contains only one feature
        # so let's use 1 line of feature file for navigation
        @current_feature_file_colon_line = feature.file_colon_line(1)
        super

        # Cucumber doesn't provide before/end event thus
        # we should close here last started issue
        unregister_tags_holder
        log_suite_finished(@current_feature_name) unless @current_feature_name.nil?
        @current_feature_name = nil
      end

      # @Processes: feature name
      # We use for loggig feature started event
      def visit_feature_name(new_feature_name)
        @current_feature_name = new_feature_name.split("\n").first || @current_feature_file_colon_line || ""
        log_suite_started(@current_feature_name, @current_feature_file_colon_line)
        # log tags because the are reported before feature name
        print_current_tags()
        super
      end

####  Examples:
      # Processes "Examples" section
      # Cucumber doesn't provide start .. end events
      # here we process examples ended event manually
      def visit_examples(examples)
        @in_outline_examples = true
        @previous_examples_scenario_outline = nil
        register_tags_holder
        super
        unregister_tags_holder
        @in_outline_examples = nil

        # close oultine of last scenario_outline in this example
        # (if it exist)
        unless @previous_examples_scenario_outline.nil?
          log_suite_finished(@current_example_or_feature_elems_stack.pop) unless @current_example_or_feature_elems_stack.empty?
          @previous_examples_scenario_outline = nil
        end

        # close example suite block
        log_suite_finished(@current_example_or_feature_elems_stack.pop) unless @current_example_or_feature_elems_stack.empty?
      end

      # Processes name of "Examples" section
      # Cucumber doesn't provide start .. end events
      # here we process examples started event manually
      def visit_examples_name(keyword, name)
        new_examples_name = "#{keyword} #{name}"

        # report example suite started
        @current_example_or_feature_elems_stack.push(new_examples_name)
        log_suite_started(new_examples_name)
        # log tags because the are reported before example name
        print_current_tags
        super
      end

#### Scenarios, Scenario Outlines and Backgrounds:
      # @Processes: Background
      # Actually all background steps will be merged with other steps of
      # 'scenarios'/'outline examples' so we shouldn't show Background as separate test suite
      def visit_background(background)
        @in_background = true
        register_tags_holder
        super
        unregister_tags_holder
        @in_background = nil
      end

#### Scenarios, Scenario Outlines(real and fake from Example's table rows):
      # @Processes: Scenario(real without examples' fake scenarios), ScenarioOutline
      # Here we can do cleanup for scenarios in current feature: Scenario, ScenarioOutline
      def visit_feature_element(feature_element)
        is_outline = feature_element.class == ::Cucumber::Ast::ScenarioOutline
        @in_outline_scenario_stack.push((is_outline) ? true : nil)
        register_tags_holder
        super
        unregister_tags_holder
        # close scenario/scenario_outline suite
        log_suite_finished(@current_example_or_feature_elems_stack.pop) unless @current_example_or_feature_elems_stack.empty?
        @in_outline_scenario_stack.pop
      end

      # @Processes: Scenario (fake and real), ScenarioOutline names
      # scenario/scenario_outline contains of name and steps
      def visit_scenario_name(keyword, name, file_colon_line, source_indent)
        if row_based_scenario_outline?
          # for fake row-related scenarios it's resonable to show row content
          # or at least line number instead of duplicating scenario_outline name
          name = "Line: #{exctract_cucumber_location(file_colon_line)[1]}";
        end
        process_new_feature_element_name(keyword, name, file_colon_line, source_indent)
        super
      end

#### Steps and Cells:
      # Processe: StepInvocation
      # We will rememeber befor step invocation and then
      # compare with time at "visit_step_result" moment
      def visit_step(step)
        register_tags_holder
        @current_step_start_time = get_current_time_in_ms
        super
        unregister_tags_holder
       end

      # result of step invocation - calls v_exception, v_step_name
      def visit_step_result(keyword, step_match, multiline_arg, status, exception, source_indent, background)
        duration_ms =  get_current_time_in_ms - @current_step_start_time

        name = step_match.format_args(lambda{|a| a})
        file_colon_line = step_match.file_colon_line

        # Actually cucmber standard formatters doesn't count BG steps in
        # context of Backgrount element. Instead it count such steps in each
        # affected scenatio
        if @in_background
          super
          return
        end

        # Also cucumber standard formatter doesn't count ScenarioOutline steps descriptions
        # e.g.
        # ------
        #   Given there are <start> cucumbers   # features/step_definitions/common_step.rb:13
        # ------
        # in this case let do not report always ingnored step, but just output step definition in console

        is_fake_outline_step = !@in_outline_scenario_stack.empty? && # if there is no active outline - all is ok
                               @in_outline_scenario_stack.last && # if not in scenario_outline - steps will be ok
                               !@in_outline_examples # examples contains correct steps
        if is_fake_outline_step
          puts format_step(keyword, step_match, status, @options[:source] ? source_indent : nil)
          super
          return
        end

        # Now we can report step as test
        step_line = "#{keyword} #{name}"
        log_test_opened(step_line, file_colon_line)

        # log tags because the are reported before step name
        print_current_tags

        log_status_and_test_finished(status, step_line, duration_ms, exception, multiline_arg, keyword)
      end

#######################################################################
#######################################################################
########### PRIVATE METHODS ###########################################
#######################################################################
#######################################################################
      private

      def row_based_scenario_outline?
        @in_outline_scenario_stack.last && @in_outline_examples
      end

      def log(msg)
        send_msg(msg)
        # returns:
        msg
      end

      def log_suite_started(suite_name, file_colon_line = nil)
        log(@message_factory.create_suite_started(suite_name,
                                                  location_from_link(*exctract_cucumber_location(file_colon_line))))
      end

      def log_suite_finished(suite_name)
        log(@message_factory.create_suite_finished(suite_name))
      end

      # reports test open for step or example table fake step_invocation
      def log_test_opened(step_line, file_colon_line = nil)
        log(@message_factory.create_test_started(step_line,
                                                 location_from_link(*exctract_cucumber_location(file_colon_line))))
      end

      # reports status and name for step or example table fake step_invocation
      # status: :passed, :pending, :undefined, :failed + :skipped, :skipped_param
      def log_status_and_test_finished(status, name, duration_ms,
                                       exception = nil, multiline_arg = nil, keyword = nil)
        msg = exception.nil? ? "" : "#{exception.class.name}: #{exception.message}"
        bactrace = exception.nil? ? "" : format_backtrace(exception.backtrace)

        case status
          when :pending
            # remove redundant information
            if (msg.index("Cucumber::Pending: ") != nil)
              msg.gsub!("Cucumber::Pending: ", "")
              msg = msg + " (Cucumber::Pending exception)"
            end
            log(@message_factory.create_test_ignored(name, msg, bactrace))
          when :skipped, :skipped_param
            log(@message_factory.create_test_ignored(name, "Skipped step"))
          when :undefined
            print_undef_step_snippet(name, exception, multiline_arg, keyword)
            # remove redundant information
            if (msg.index("Cucumber::Undefined: ") != nil)
              msg.gsub!("Cucumber::Undefined: ", "")
              msg = msg + " (Cucumber::Undefined exception)"
            end
            log(@message_factory.create_test_error(name, msg, bactrace))
          when :failed
            log(@message_factory.create_test_failed(name,  msg, bactrace))
        end
        log(@message_factory.create_test_finished(name, duration_ms.nil? ? 0 : duration_ms))
      end

      def process_new_feature_element_name(keyword, name, file_colon_line, source_indent)
        # TODO rename to new_feature_element_name
        new_bg_or_feature_element_name = "#{keyword} #{name}"
        if @in_outline_examples && !@previous_examples_scenario_outline.nil?
          # Examples doesn't allow to identify scenario finished event
          # so we will close prev scenario
          log_suite_finished(@current_example_or_feature_elems_stack.pop)
        end
        # report suite started
        @previous_examples_scenario_outline = new_bg_or_feature_element_name
        @current_example_or_feature_elems_stack.push(new_bg_or_feature_element_name)
        log_suite_started(new_bg_or_feature_element_name, file_colon_line)
        # log tags because the are reported before Background or Feature
        print_current_tags
      end

      def exctract_cucumber_location(file_colon_line)
        if file_colon_line =~ /(.+):(\d+)/
          return get_pair_by($1, $2)
        end
        return nil, nil
      end

      # Summary
      def print_summary(features)
        # If defined both old and new >= 0.3.8 api we should use
        # new one, because old api is backward compatibility
        if !(defined? print_stats) && (defined? print_counts)
          # cucumber < 0.3.8
          print_counts
        else
          # cucumber >= 0.3.8
          print_stats(features)
        end
      end

      # Tags
      def print_tags_collection(tags)
        return if tags.empty?
        print "Tag#{tags.length > 1 ? "s" : ""}: "
        tags.each do |tag|
          print "#{tag}#{tag != tags[-1] ? ', ' : ""}"
        end
        puts
      end

      # Register holder in stack which allows us to show tags
      # under corresponding feature/scenarions/sc_ountilne/step node. This
      # is necessarry due to cucumber's AST and visitor API specific
      def register_tags_holder
        @tags_holder_stack.push(TagsHolder.new)
      end

      def unregister_tags_holder
        # on exit we should remove visitor and dump tags(if they weren't dumped)
        print_current_tags
        @tags_holder_stack.pop
      end

      def print_current_tags()
        holder = @tags_holder_stack.last
        print_tags_collection(holder.tags)
        holder.clear_tags
      end

      # prints snippets for undefined steps
      def print_undef_step_snippet(step_name, step_exception, step_multiline_arg, step_keyword)
        step_name = ::Cucumber::Undefined === step_exception ? step_exception.step_name : step_name
        step_multiline_class = step_multiline_arg ? step_multiline_arg.class : nil
        snippet = @step_mother.snippet_text(step_keyword || "", step_name, step_multiline_class)

        text = " \nYou can implement step definitions for undefined steps with these snippets:\n\n#{snippet}"
        puts text
      end

      # Instance of this class allow to store tags for
      # current holder: feature, example, features_element, etc
      class TagsHolder
        attr_reader :tags
        def initialize
          @tags = []
        end
        def add_tag(tag)
          @tags << tag
        end
        def clear_tags
          @tags.clear
        end
      end

end