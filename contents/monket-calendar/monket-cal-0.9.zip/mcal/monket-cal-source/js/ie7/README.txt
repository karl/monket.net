Installation
------------

Follow these simple instructions to get IE7 working immediately on your server:

 * download the latest IE7 ZIP file (https://sourceforge.net/project/showfiles.php?group_id=109983&package_id=119707)

 * extract the contents to a directory on your server (keep the folder names used in the ZIP)

 * you will now have an IE7 directory on your server

 * include the IE7 JavaScript library in the page you wish to test

   <!-- compliance patch for microsoft browsers -->
   <!--[if lt IE 7]><script src="/ie7/ie7-standard-p.js" type="text/javascript"></script><![endif]-->

 * make sure this also points to the same directory

 * open the page in your web browser

 * the page should now be IE7 enabled.

 * if you are using the PNG solution then be aware that it operates on files
   names "something-trans.png"

 * see this page for more configuration and usage options:
   http://dean.edwards.name/IE7/usage/

You may extract the contents of the ZIP file to your hard disk if you do not have access to a web server.


Enjoy ;-)

Dean Edwards, 23rd May 2005
