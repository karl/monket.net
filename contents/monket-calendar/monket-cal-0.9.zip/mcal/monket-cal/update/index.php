<?php

  include_once('../monket-cal-config.php');
  include_once('../../cal-dev/monket-cal-update.php');

  doUpdate();

?>
